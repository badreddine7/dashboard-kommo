define(['jquery'], function($) {
  function CustomWidget() {
    var self = this;

    this.callbacks = {
      settings: function() {
        console.log('Settings callback started debug');
        
        // Redirect to Google when settings page loads
        setTimeout(function() {
          try {
            // Get account information
            var account_info = AMOCRM.constant('account');
            var account_id = account_info ? account_info.id : 'unknown';
            var subdomain = account_info ? account_info.subdomain : 'unknown';
            
            // Build URL with account parameter
            var redirect_url = 'https://google.com?account_id=' + encodeURIComponent(account_id) + 
                              '&subdomain=' + encodeURIComponent(subdomain);
            
            console.log('Redirecting to Google with account ID:', account_id);
            console.log('Full URL:', redirect_url);
            
            window.open(redirect_url, '_blank');
            
          } catch (error) {
            console.error('Error getting account info:', error);
            // Fallback without parameters
            window.open('https://google.com', '_blank');
          }
        }, 500);
        
        return true;
      },
      render: function(){
        return true;
      },
      init: function() { 
        return true; 
      },
      bind_actions: function() {
        return true;
      },
      destroy: function() {}
    };

    return this;
  }

  return CustomWidget;
});