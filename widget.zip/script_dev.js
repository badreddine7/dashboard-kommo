define(['jquery'], function($) {
  var SalesWidget = function() {
    var self = this;

    this.callbacks = {
      render: function() {
        var container = $('<div>')
          .addClass('sales-widget')
          .text('Loading sales report...');

        self.render_template({ body: container.prop('outerHTML') });
        return true;
      },

      init: function() {
        // Sample test data — no backend required
        const sample = {
          generated_at: new Date().toISOString(),
          reps: [
            { name: 'Alice', total_leads: 12, tasks: { created: 5, completed: 3, overdue: 1 }, conversion: { '1->2': 0.5, '2->3': 0.3 } },
            { name: 'Bob',   total_leads: 8,  tasks: { created: 4, completed: 4, overdue: 0 }, conversion: { '1->2': 0.7, '2->3': 0.2 } }
          ]
        };

        // Build static cards
        const html = `<h3>Sales as of ${sample.generated_at.slice(0,10)}</h3>` +
          sample.reps.map(r =>
            `<div class="rep-card" style="
              border:1px solid #ddd; padding:8px; margin:6px 0; border-radius:4px;
              background:#f9f9f9;">
              <strong>${r.name}</strong><br>
              Leads: ${r.total_leads}<br>
              Tasks created/completed/overdue: ${r.tasks.created}/${r.tasks.completed}/${r.tasks.overdue}<br>
              Conversion: ${Object.entries(r.conversion)
                .map(([k,v]) => `${k}: ${(v*100).toFixed(1)}%`).join(', ')}
            </div>`
          ).join('');

        self.render_template({ body: html });
        return true;
      },

      bind_actions: function() {
        return true;
      }
    };

    return this;
  };
  return SalesWidget;
});
